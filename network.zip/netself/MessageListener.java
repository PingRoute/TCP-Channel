public interface MessageListener {
  public void messageReceived(String message, int clientID);
}